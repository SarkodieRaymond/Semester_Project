
#include <iostream>

using namespace std;

int option;

int main(){
	cout<<"                                      "<<endl;
	cout<<"                                      "<<endl;
	cout<<"             INVENTORY SYSTEM         "<<endl;
	cout<<"                                      "<<endl;
	cout<<"                  MENU                "<<endl;
	cout<<"          _______________________     "<<endl;
	cout<<"1. Add NewItem"<<endl;
	cout<<"2. Display List of Goods"<<endl;
	cout<<"3. Exist"<<endl;
	cout<<"------------------------"<<endl;
	cout<<"option"<<endl;
	cin>>option;
	
	system("cls");
	
	int choice;
	
	
	switch(option){
		case 1:
		string ItemName;
		int ItemQuantity;
		double ItemPrice;
		do{	
			cout<<"             Add NewItem              "<<endl;
			cout<<"                                      "<<endl;
			cout<<"1. Item Name   "<<endl;
			cin>>      ItemName;
			cout<<"                                      "<<endl;
			cout<<"2. Item Quantity   "<<endl;
			cin>>      ItemQuantity;
			cout<<"                                      "<<endl;
			cout<<"3. Item Price   "<<endl;
			cin>>      ItemPrice;
			
		system("cls");
			
			cout<<"Item Name: "<<ItemName<<endl;
			cout<<"                                      "<<endl;
			cout<<"Item Quantity: "<<ItemQuantity<<endl;
			cout<<"                                      "<<endl;
			cout<<"Item Price: "<<ItemPrice<<endl;
			cout<<"                                      "<<endl;
			
			cout<<"1. Save Details"<<endl;
			cout<<"2. Cancel Details"<<endl;
			
			cout<<"                                      "<<endl;
			
			cout<<"select an option"<<endl;
			cin>>choice;
			system("cls");
			switch(choice){
				case 1:
					cout<<"details save successful"<<endl;
					break;
				case 2:
			    	cout<<"details  cancelled. try again!"<<endl;
					break;
			}
	       }while(choice==2);
	       
	break;
	} 
	
	switch(option){
		 case 2:
	       cout<<"------Display List of Goods-----"<<endl;
	       cout<<"item                               ";
	       cout<<"quantity"<<endl;
	          cout<<"Rice                            ";
	       cout<<" 5 bags"<<endl;
	          cout<<"Sugar                           ";
	       cout<<"10 bags"<<endl;
	          cout<<"Tomato paste                    ";
	       cout<<"20 boxes"<<endl;
	          cout<<"salt                            ";
	       cout<<"50 bag"<<endl;
	          cout<<"Washing Powder                  ";
	       cout<<"90 bags"<<endl;
	          cout<<"Beans                           ";
	       cout<<" 3 bags"<<endl;
	break;      
	}
	
	int chioce;
	switch(option){
		case 3:
			cout<<"                                "<<endl;
			cout<<"       Exist System             "<<endl;
			cout<<"                                "<<endl;
			cout<<"1. YES"<<endl;
			cout<<"2. NO"<<endl;
			
			cout<<"chioce"<<endl;
			cin>>chioce;
			system("cls");
			switch(chioce){
				case 1:
					cout<<"Thank YOU for your service"<<endl;
					break;
				
				
			}
			
	break;
	}
	defualt:
		    
	
	
return 0;	
}
